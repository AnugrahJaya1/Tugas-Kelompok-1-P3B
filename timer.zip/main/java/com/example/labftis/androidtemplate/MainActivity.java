package com.example.labftis.androidtemplate;

import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private static final long START_TIME=60000;

    private TextView tv_waktu;
    private Button btnStart;

    private CountDownTimer timer;
    private boolean running;

    private long timeLeft=START_TIME;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.tv_waktu=this.findViewById(R.id.tv_waktu);
        this.btnStart=this.findViewById(R.id.btnStart);

        this.btnStart.setOnClickListener(this);
        updateCountDownText();
    }

    @Override
    public void onClick(View view) {
        if(view==btnStart && btnStart.getText().toString().equals("Start")){
            startTimer();
        }
        else{
            resetTimer();
        }
    }

    public void startTimer(){
        timer=new CountDownTimer(timeLeft,1000) {
            @Override
            public void onTick(long l) {
                timeLeft=l;
                updateCountDownText();
            }

            @Override
            public void onFinish() {
                running=false;
                timer.cancel();
                btnStart.setText("Start");
                timeLeft=START_TIME;
            }
        }.start();
        running=true;
        btnStart.setText("Finish");
    }
    public void resetTimer(){
        timeLeft=START_TIME;
        timer.cancel();
        btnStart.setText("Start");
        updateCountDownText();
    }
    private void updateCountDownText(){
        int minutes=(int) (timeLeft/1000)/60;
        int seconds=(int) (timeLeft/1000)%60;

        String timeLeftFormat=String.format(Locale.getDefault(),"%02d:%02d",minutes,seconds);
        this.tv_waktu.setText(timeLeftFormat);
    }
}
